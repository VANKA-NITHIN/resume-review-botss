# AI Resume Review Bot

Upload your resume (PDF) and get GPT-4-powered feedback for tech and AI jobs.

## How to Use

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Run the app:
   ```
   streamlit run app.py
   ```

3. Make sure to set your OpenAI API key as an environment variable:
   ```
   OPENAI_API_KEY=your-api-key
   ```